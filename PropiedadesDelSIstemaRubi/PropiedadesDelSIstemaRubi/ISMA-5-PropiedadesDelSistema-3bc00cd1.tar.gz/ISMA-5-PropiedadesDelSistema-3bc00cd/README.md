PropiedadesDelSistema
=====================

Este proyecto consiste e desarrollar una aplicacion que muestre las propiedades importantes de tu maquina(Memoria Ram,CPU,etc) de manera visual